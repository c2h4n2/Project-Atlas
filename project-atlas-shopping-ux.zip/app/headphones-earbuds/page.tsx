import type { Metadata } from "next";
import Link from "next/link";
import ProductExplorer from "@/components/ProductExplorer";
import { products } from "@/data/products";

export const metadata: Metadata = {
  title: "Headphones & Earbuds",
  description:
    "Search and compare Project Atlas reviews of wireless headphones and earbuds.",
};

export default function HeadphonesEarbudsPage() {
  const categoryProducts = products.filter(
    (product) => product.categoryId === "headphones-earbuds",
  );

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <section className="border-b border-white/10">
        <div className="mx-auto max-w-7xl px-6 py-16">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
            Headphones & Earbuds
          </p>

          <h1 className="mt-4 text-4xl font-bold sm:text-6xl">
            Find the right wireless audio
          </h1>

          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
            Search {categoryProducts.length} headphones and earbuds, filter by
            brand, and sort by Atlas score, customer feedback, or review
            volume.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/best-headphones-earbuds"
              className="rounded-full bg-cyan-400 px-6 py-3.5 font-bold text-slate-950 transition hover:bg-cyan-300"
            >
              View Top Picks
            </Link>

            <Link
              href="/compare?category=headphones-earbuds"
              className="rounded-full border border-white/20 bg-white/5 px-6 py-3.5 font-bold transition hover:border-cyan-400/50 hover:bg-white/10"
            >
              Compare Products
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 sm:py-14">
        <ProductExplorer
          products={categoryProducts}
          showBrandFilter
        />
      </section>
    </main>
  );
}
