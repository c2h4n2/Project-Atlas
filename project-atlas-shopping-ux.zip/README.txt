Project Atlas — Shopping UX Upgrade

Adds:
- Product search
- Category filters on All Products
- Brand filters
- Sorting by Atlas score, customer rating, review count, and product name
- Search/filter/sort on AI Glasses
- Search/filter/sort on Headphones & Earbuds
- Related products on every product review page

Files:
components/ProductExplorer.tsx
app/all-products/page.tsx
app/ai-glasses/page.tsx
app/headphones-earbuds/page.tsx
app/products/[slug]/page.tsx

HOW TO APPLY

1. Drag project-atlas-shopping-ux.zip into the top-level Project-Atlas folder.

2. Run:

rm -rf /tmp/atlas-shopping-ux
mkdir -p /tmp/atlas-shopping-ux
unzip -o project-atlas-shopping-ux.zip -d /tmp/atlas-shopping-ux

cp /tmp/atlas-shopping-ux/components/ProductExplorer.tsx components/ProductExplorer.tsx
cp /tmp/atlas-shopping-ux/app/all-products/page.tsx app/all-products/page.tsx
cp /tmp/atlas-shopping-ux/app/ai-glasses/page.tsx app/ai-glasses/page.tsx
cp /tmp/atlas-shopping-ux/app/headphones-earbuds/page.tsx app/headphones-earbuds/page.tsx
cp /tmp/atlas-shopping-ux/app/products/\[slug\]/page.tsx app/products/\[slug\]/page.tsx

3. Run:

npm run check

4. Restart local site if needed:

npm run dev -- --hostname 0.0.0.0

5. Test:
/
 /all-products
 /ai-glasses
 /headphones-earbuds
 /products/sony-wh-1000xm6
 /products/ray-ban-meta-wayfarer-gen-2

6. Test search:
- Sony
- Samsung
- Ray-Ban
- travel
- Apple

7. Test filters and sorting.

Do not deploy until the local pages look correct.
