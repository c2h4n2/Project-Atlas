Project Atlas — Header Suspense fix

This fixes the Next.js build error:
useSearchParams() should be wrapped in a suspense boundary.

Replace:
components/Header.tsx

Then run:
npm run check
