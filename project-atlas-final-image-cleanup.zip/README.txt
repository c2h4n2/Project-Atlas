Project Atlas — Final image cleanup

Replaces the remaining bad/missing images for:
- XREAL One Pro
- XREAL 1S
- Samsung Galaxy Buds3 Pro
- Samsung Galaxy Buds3

HOW TO APPLY

1. Drag this ZIP into the top-level Project-Atlas folder in Codespaces.

2. Run:

rm -rf /tmp/atlas-final-images
mkdir -p /tmp/atlas-final-images
unzip -o project-atlas-final-image-cleanup.zip -d /tmp/atlas-final-images
cp /tmp/atlas-final-images/public/products/*.webp public/products/

3. Restart the local dev server if needed.

4. Hard refresh with Ctrl+Shift+R.

5. Check:
   /ai-glasses
   /headphones-earbuds
   /products/xreal-one-pro
   /products/xreal-1s
   /products/samsung-galaxy-buds3-pro
   /products/samsung-galaxy-buds3

6. Run:
   npm run check

Do not deploy until the local pages look correct.
