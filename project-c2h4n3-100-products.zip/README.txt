Project C2H4N3 — 100 Product Milestone

Adds 25 products:
- 16 Headphones & Earbuds
- 9 Smartwatches
- Expected total after install: 100 products

Apply:

rm -rf /tmp/c2h4n3-100
mkdir -p /tmp/c2h4n3-100
unzip -o project-c2h4n3-100-products.zip -d /tmp/c2h4n3-100

cp /tmp/c2h4n3-100/data/products.ts data/products.ts
cp /tmp/c2h4n3-100/data/products/expansion-to-100.ts data/products/expansion-to-100.ts
cp /tmp/c2h4n3-100/scripts/audit-100-products.ts scripts/audit-100-products.ts

npx tsx scripts/audit-100-products.ts
npm run check

If both pass:
npm run sync-product-images

Then visually test:
/all-products
/headphones-earbuds
/smartwatches
/top-picks

Do not deploy until images and local pages look correct.
