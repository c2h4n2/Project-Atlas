C2H4N3 Header V2 Cache Fix

This uses a NEW filename so Next.js/browser caching cannot keep the old logo.

Apply:

rm -rf /tmp/c2h4n3-v2-cachefix
mkdir -p /tmp/c2h4n3-v2-cachefix
unzip -o project-atlas-c2h4n3-branding-v2-cachefix.zip -d /tmp/c2h4n3-v2-cachefix

mkdir -p public/brand
cp /tmp/c2h4n3-v2-cachefix/public/brand/c2h4n3-header-v2.webp public/brand/c2h4n3-header-v2.webp
cp /tmp/c2h4n3-v2-cachefix/components/Header.tsx components/Header.tsx

rm -rf .next
npm run check

Then restart dev:
npm run dev -- --hostname 0.0.0.0

Hard refresh the browser.
