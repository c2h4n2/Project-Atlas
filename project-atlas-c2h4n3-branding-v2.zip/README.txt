C2H4N3 Header Branding V2

Apply:

rm -rf /tmp/c2h4n3-branding-v2
mkdir -p /tmp/c2h4n3-branding-v2
unzip -o project-atlas-c2h4n3-branding-v2.zip -d /tmp/c2h4n3-branding-v2

mkdir -p public/brand
cp /tmp/c2h4n3-branding-v2/public/brand/c2h4n3-header.webp public/brand/c2h4n3-header.webp

npm run check
