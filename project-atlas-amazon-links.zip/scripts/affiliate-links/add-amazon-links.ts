import fs from "node:fs";
import path from "node:path";
import { products } from "../../data/products";

const AMAZON_TAG = "chhx2nun03-20";
const filesByCategory: Record<string, string> = {
  "ai-glasses": "data/products/ai-glasses.ts",
  "headphones-earbuds": "data/products/headphones-earbuds.ts",
  smartwatches: "data/products/smartwatches.ts",
};

function urlFor(name: string) {
  return `https://www.amazon.com/s?k=${encodeURIComponent(name)}&tag=${AMAZON_TAG}`;
}

function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function addLink(source: string, slug: string, name: string) {
  const slugMatch = new RegExp(`slug:\\s*["']${escapeRegex(slug)}["']`).exec(source);
  if (!slugMatch) throw new Error(`Could not find slug: ${slug}`);

  const start = slugMatch.index;
  const next = source.indexOf("slug:", start + slugMatch[0].length);
  const end = next === -1 ? source.length : next;
  const block = source.slice(start, end);

  if (/retailer:\s*["']Amazon["']/.test(block)) return source;

  const affiliate = /affiliateLinks:\s*\[\s*\]/.exec(block);
  if (!affiliate) throw new Error(`affiliateLinks is not empty for ${slug}; review manually.`);

  const replacement = `affiliateLinks: [{ retailer: "Amazon", url: "${urlFor(name)}" }]`;
  const a = start + affiliate.index;
  const b = a + affiliate[0].length;
  return source.slice(0, a) + replacement + source.slice(b);
}

const grouped = new Map<string, typeof products>();
for (const product of products) {
  const categoryId = product.categoryId ?? "ai-glasses";
  const file = filesByCategory[categoryId];
  if (!file) continue;
  const arr = grouped.get(file) ?? [];
  arr.push(product);
  grouped.set(file, arr);
}

let updated = 0;
for (const [relativeFile, list] of grouped) {
  const file = path.resolve(process.cwd(), relativeFile);
  let source = fs.readFileSync(file, "utf8");
  for (const product of list) {
    const before = source;
    source = addLink(source, product.slug, product.name);
    if (source !== before) updated++;
  }
  fs.writeFileSync(file, source, "utf8");
}

console.log(`Amazon tracking ID: ${AMAZON_TAG}`);
console.log(`Products updated: ${updated}`);
