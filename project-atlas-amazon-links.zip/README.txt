Project Atlas — Amazon Associates Links

Tracking ID: chhx2nun03-20

Apply:

rm -rf /tmp/atlas-amazon-links
mkdir -p /tmp/atlas-amazon-links
unzip -o project-atlas-amazon-links.zip -d /tmp/atlas-amazon-links

cp /tmp/atlas-amazon-links/components/RetailerButtons.tsx components/RetailerButtons.tsx

mkdir -p scripts/affiliate-links
cp /tmp/atlas-amazon-links/scripts/affiliate-links/add-amazon-links.ts scripts/affiliate-links/add-amazon-links.ts

npx tsx scripts/affiliate-links/add-amazon-links.ts
npx tsx scripts/affiliate-links/audit-retailer-links.ts
npm run check

Expected audit:
Products: 75
With retailer links: 75
Without retailer links: 0
Amazon: 75

These are tracked Amazon search-result links for the exact product names. The UI says "Search Amazon" so it does not imply the exact item is confirmed in stock. Later, verified direct ASIN links can replace them.
