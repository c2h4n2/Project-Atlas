Project C2H4N3 — 125 Product Milestone

Adds 25 products: 15 audio + 10 smartwatches.

Apply:
rm -rf /tmp/c2h4n3-125
mkdir -p /tmp/c2h4n3-125
unzip -o project-c2h4n3-125-products.zip -d /tmp/c2h4n3-125
cp /tmp/c2h4n3-125/data/products/expansion-to-125.ts data/products/expansion-to-125.ts
cp /tmp/c2h4n3-125/scripts/apply-125-expansion.ts scripts/apply-125-expansion.ts
cp /tmp/c2h4n3-125/scripts/audit-125-products.ts scripts/audit-125-products.ts
npx tsx scripts/apply-125-expansion.ts
npx tsx scripts/audit-125-products.ts
npm run check
npm run sync-product-images

Expected audit: Products 125 / Unique 125 / Duplicates 0.
Do not deploy until local image review is complete.
