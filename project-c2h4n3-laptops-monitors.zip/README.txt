Project C2H4N3 — Laptops + Monitors

Adds two new categories:
- Laptops: 15 products
- Monitors: 15 products

Apply:
rm -rf /tmp/c2h4n3-lm
mkdir -p /tmp/c2h4n3-lm
unzip -o project-c2h4n3-laptops-monitors.zip -d /tmp/c2h4n3-lm

cp /tmp/c2h4n3-lm/data/products/laptops.ts data/products/laptops.ts
cp /tmp/c2h4n3-lm/data/products/monitors.ts data/products/monitors.ts
cp /tmp/c2h4n3-lm/app/laptops/page.tsx app/laptops/page.tsx
cp /tmp/c2h4n3-lm/app/monitors/page.tsx app/monitors/page.tsx
cp /tmp/c2h4n3-lm/app/best-laptops/page.tsx app/best-laptops/page.tsx
cp /tmp/c2h4n3-lm/app/best-monitors/page.tsx app/best-monitors/page.tsx
cp /tmp/c2h4n3-lm/scripts/apply-laptops-monitors.ts scripts/apply-laptops-monitors.ts
cp /tmp/c2h4n3-lm/scripts/audit-laptops-monitors.ts scripts/audit-laptops-monitors.ts

npx tsx scripts/apply-laptops-monitors.ts
npx tsx scripts/audit-laptops-monitors.ts
npm run check

IMPORTANT:
This package intentionally does not overwrite data/categories.ts.
After running the patch, if it prints that category configs are missing,
paste data/categories.ts here and we will add Laptops and Monitors cleanly.

After category config is wired:
npm run sync-product-images

Do not deploy until images are reviewed.
