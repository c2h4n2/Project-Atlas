import ProductExplorer from "@/components/ProductExplorer";
import { products } from "@/data/products";

export default function LaptopsPage() {
  const categoryProducts = products.filter(
    (product) => product.categoryId === "laptops",
  );

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <section className="mx-auto max-w-7xl px-6 py-12">
        <p className="text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
          COMPUTING
        </p>
        <h1 className="mt-4 text-5xl font-black tracking-tight sm:text-6xl">
          Laptops
        </h1>
        <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
          Search and compare Project C2H4N3 laptop reviews across ultraportables, premium productivity systems, gaming laptops, and mobile workstations.
        </p>
        <div className="mt-10">
          <ProductExplorer products={categoryProducts} />
        </div>
      </section>
    </main>
  );
}
