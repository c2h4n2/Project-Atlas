Project C2H4N3 — Rating Display Upgrade

Apply:

rm -rf /tmp/c2h4n3-rating-display
mkdir -p /tmp/c2h4n3-rating-display
unzip -o project-c2h4n3-rating-display.zip -d /tmp/c2h4n3-rating-display

cp /tmp/c2h4n3-rating-display/components/CustomerRating.tsx components/CustomerRating.tsx
cp /tmp/c2h4n3-rating-display/components/EditorialScore.tsx components/EditorialScore.tsx
cp /tmp/c2h4n3-rating-display/scripts/apply-rating-display.ts scripts/apply-rating-display.ts

npx tsx scripts/apply-rating-display.ts
npm run check

Expected on cards:

C2H4N3 SCORE
★ 9.4 / 10

CUSTOMER RATING
★★★★★ 4.8 / 5

or:

CUSTOMER RATING
★ Not Rated
Awaiting verified customer reviews.
