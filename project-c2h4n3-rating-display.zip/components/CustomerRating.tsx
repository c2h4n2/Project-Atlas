type Props = {
  rating: number;
  reviewCount: number;
};

function getStars(rating: number) {
  const filled = Math.max(0, Math.min(5, Math.round(rating)));
  return `${"★".repeat(filled)}${"☆".repeat(5 - filled)}`;
}

export default function CustomerRating({ rating, reviewCount }: Props) {
  if (reviewCount <= 0 || rating <= 0) {
    return (
      <div>
        <p className="text-xl font-black">
          <span className="text-amber-400">★</span>{" "}
          <span className="text-white">Not Rated</span>
        </p>
        <p className="mt-1 text-[11px] text-slate-500">
          Awaiting verified customer reviews.
        </p>
      </div>
    );
  }

  return (
    <div>
      <p className="flex flex-wrap items-center gap-2 text-lg font-black">
        <span className="tracking-[0.05em] text-amber-400">
          {getStars(rating)}
        </span>
        <span className="text-white">{rating.toFixed(1)} / 5</span>
      </p>
      <p className="mt-1 text-[11px] text-slate-500">
        {reviewCount.toLocaleString()} verified customer{" "}
        {reviewCount === 1 ? "review" : "reviews"}.
      </p>
    </div>
  );
}
