Project Atlas — Multi-Retailer Affiliate UI

WHAT THIS RELEASE DOES

- Supports multiple retailer buttons per product.
- Retailers are ordered:
  1. Amazon
  2. Walmart
  3. Target
  4. Costco
  5. Best Buy
  6. Other retailers
- Product cards show up to two available retailer buttons.
- Full product pages show every available retailer button.
- Primary retailer button is visually emphasized.
- Existing affiliate disclosure language is preserved.
- All retailer links use:
  rel="nofollow sponsored noopener noreferrer"

IMPORTANT

This release does NOT invent Amazon/Walmart/Target/Costco affiliate URLs.
Only real URLs already stored in each product's affiliateLinks array are shown.

When you receive an Amazon Associates tracking ID, add the real Amazon affiliate
URL to each applicable product like:

affiliateLinks: [
  {
    retailer: "Amazon",
    url: "YOUR REAL AMAZON ASSOCIATES URL",
  },
  {
    retailer: "Walmart",
    url: "YOUR REAL WALMART AFFILIATE URL",
  },
],

The UI will automatically put Amazon first.

HOW TO APPLY

1. Drag project-atlas-multi-retailer-affiliate.zip into the Project-Atlas root.

2. Run:

rm -rf /tmp/atlas-retailers
mkdir -p /tmp/atlas-retailers
unzip -o project-atlas-multi-retailer-affiliate.zip -d /tmp/atlas-retailers

cp /tmp/atlas-retailers/data/retailers.ts data/retailers.ts
cp /tmp/atlas-retailers/components/RetailerButtons.tsx components/RetailerButtons.tsx
cp /tmp/atlas-retailers/components/ProductCard.tsx components/ProductCard.tsx
cp /tmp/atlas-retailers/app/products/\[slug\]/page.tsx app/products/\[slug\]/page.tsx

mkdir -p scripts/affiliate-links
cp /tmp/atlas-retailers/scripts/affiliate-links/audit-retailer-links.ts scripts/affiliate-links/audit-retailer-links.ts

3. Run:

npm run check

4. Optional retailer-link audit:

npx tsx scripts/affiliate-links/audit-retailer-links.ts

5. Test locally:
- Any product page with retailer links
- /all-products
- /top-picks
- /smartwatches
- /headphones-earbuds
- /ai-glasses

No retailer button will appear on products whose affiliateLinks array is empty.
