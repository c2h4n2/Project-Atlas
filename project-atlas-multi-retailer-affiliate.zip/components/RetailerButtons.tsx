"use client";

import { sortRetailerLinks } from "@/data/retailers";
import type { AffiliateLink } from "@/data/products";

type RetailerButtonsProps = {
  links: AffiliateLink[];
  compact?: boolean;
  maxLinks?: number;
};

export default function RetailerButtons({
  links,
  compact = false,
  maxLinks,
}: RetailerButtonsProps) {
  const sortedLinks = sortRetailerLinks(links);
  const visibleLinks =
    typeof maxLinks === "number" ? sortedLinks.slice(0, maxLinks) : sortedLinks;

  if (visibleLinks.length === 0) {
    return null;
  }

  return (
    <div>
      <div className={compact ? "flex flex-col gap-2" : "flex flex-col gap-3 sm:flex-row sm:flex-wrap"}>
        {visibleLinks.map((link, index) => {
          const isPrimary = index === 0;

          return (
            <a
              key={`${link.retailer}-${link.url}`}
              href={link.url}
              target="_blank"
              rel="nofollow sponsored noopener noreferrer"
              className={
                compact
                  ? isPrimary
                    ? "rounded-full bg-amber-400 px-5 py-3 text-center text-sm font-black text-slate-950 transition hover:bg-amber-300"
                    : "rounded-full border border-white/20 bg-white/5 px-5 py-3 text-center text-sm font-bold text-white transition hover:border-cyan-400/50 hover:bg-white/10"
                  : isPrimary
                    ? "rounded-full bg-amber-400 px-6 py-3.5 text-center font-black text-slate-950 transition hover:bg-amber-300"
                    : "rounded-full border border-white/20 bg-white/5 px-6 py-3.5 text-center font-bold text-white transition hover:border-cyan-400/50 hover:bg-white/10"
              }
            >
              {isPrimary ? "Check price at" : "Also at"} {link.retailer}
            </a>
          );
        })}
      </div>

      {!compact && (
        <p className="mt-3 text-xs leading-5 text-slate-500">
          Retailer availability and pricing can change. Project Atlas may earn
          a commission from qualifying purchases at no additional cost to you.
        </p>
      )}
    </div>
  );
}
