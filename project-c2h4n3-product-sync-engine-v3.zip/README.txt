Project C2H4N3 — Product Sync Engine v3

This is the resilient v3 foundation.

Key change:
Image failures NO LONGER stop customer-rating collection.

Pipeline:
1. Product health audit (fatal)
2. Image sync (warning only)
3. Public web rating collector (warning only)
4. Rating import (fatal)
5. Rating audit (fatal)
6. Final product health audit (fatal)
7. Full npm run check (fatal)
8. JSON report

INSTALL

rm -rf /tmp/c2h4n3-sync-v3
mkdir -p /tmp/c2h4n3-sync-v3

unzip -o project-c2h4n3-product-sync-engine-v3.zip -d /tmp/c2h4n3-sync-v3

mkdir -p scripts/product-sync-v3

cp /tmp/c2h4n3-sync-v3/scripts/product-sync-v3/runner.ts scripts/product-sync-v3/runner.ts
cp /tmp/c2h4n3-sync-v3/scripts/audit-product-health.ts scripts/audit-product-health.ts
cp /tmp/c2h4n3-sync-v3/scripts/sync-products-v3.ts scripts/sync-products-v3.ts
cp /tmp/c2h4n3-sync-v3/scripts/apply-product-sync-engine-v3.ts scripts/apply-product-sync-engine-v3.ts

npx tsx scripts/apply-product-sync-engine-v3.ts
npm run check

TEST

npm run sync-products:dry

NORMAL USE

npm run sync-products

RATINGS ONLY

npm run sync-products:ratings-only

HEALTH

npm run product-health

REPORT

customer-ratings/product-sync-v3-report.json

NOTE

This v3 package intentionally reuses your installed public-web collector:
scripts/collect-customer-ratings-web.ts

That lets us stabilize orchestration first. The next v3 increment is retailer-
specific discovery/extraction adapters so rating coverage can grow without
breaking the main pipeline.
