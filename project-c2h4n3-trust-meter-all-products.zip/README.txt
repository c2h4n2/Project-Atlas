Apply:

rm -rf /tmp/c2h4n3-trust-meter
mkdir -p /tmp/c2h4n3-trust-meter
unzip -o project-c2h4n3-trust-meter-all-products.zip -d /tmp/c2h4n3-trust-meter

cp /tmp/c2h4n3-trust-meter/components/TrustMeter.tsx components/TrustMeter.tsx
cp /tmp/c2h4n3-trust-meter/scripts/apply-trust-meter-all-products.ts scripts/apply-trust-meter-all-products.ts

npx tsx scripts/apply-trust-meter-all-products.ts
npm run check

Then test /all-products and the category pages.
