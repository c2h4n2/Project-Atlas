Project C2H4N3 — Product Sync Engine

GOAL
====
After adding new product records, run one command:

npm run sync-products

The engine orchestrates the systems already built for C2H4N3:

1. Catalog audit
2. Product image sync
3. Online customer rating collector
4. Exact-match rating validation
5. Customer rating CSV update
6. Customer rating import
7. Customer rating audit
8. Production lint/typecheck/build
9. Machine-readable sync report

INSTALL
=======
rm -rf /tmp/c2h4n3-product-sync
mkdir -p /tmp/c2h4n3-product-sync

unzip -o project-c2h4n3-product-sync-engine.zip \
  -d /tmp/c2h4n3-product-sync

mkdir -p scripts/product-sync

cp /tmp/c2h4n3-product-sync/scripts/sync-products.ts \
  scripts/sync-products.ts

cp /tmp/c2h4n3-product-sync/scripts/product-sync/*.ts \
  scripts/product-sync/

cp /tmp/c2h4n3-product-sync/scripts/apply-product-sync-engine.ts \
  scripts/apply-product-sync-engine.ts

npx tsx scripts/apply-product-sync-engine.ts
npm run check

NORMAL WORKFLOW
===============
After adding new products:

npm run sync-products

This will:
- download missing images
- collect online ratings for unrated products
- write strict exact matches
- import the combined customer rating data
- audit the catalog
- run the full production check

DRY RUN
=======
Before a large catalog change:

npm run sync-products:dry

This:
- audits the catalog
- runs the online rating collector in dry-run mode
- does NOT download images
- does NOT write rating CSV data
- still produces collector/report output

OTHER COMMANDS
==============
Skip image work:
npm run sync-products:no-images

Ratings only:
npm run sync-products:ratings-only

Recheck every product instead of only unrated products:
npm run sync-products -- --all-ratings

BEST BUY
========
If using the Best Buy adapter:

export BEST_BUY_API_KEY="YOUR_KEY"

Do not commit the key.

OTHER RETAILERS
===============
Exact product URLs can continue to be placed in:
customer-ratings/source-seeds.csv

The existing online collector attempts to read Product.aggregateRating
structured data and rejects ambiguous model matches.

REPORTS
=======
customer-ratings/collector-report.json
customer-ratings/product-sync-report.json

IMPORTANT
=========
This engine orchestrates the existing scripts. It does not weaken the
exact-model rule and does not invent customer ratings.

A product stays Not Rated when no trustworthy exact-match customer
rating source can be collected.
