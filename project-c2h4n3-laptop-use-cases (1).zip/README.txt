Project C2H4N3 — Laptop Use-Case Filters

Adds laptop browsing by:
- Study
- Business
- Engineering
- Gaming
- Coding

Apply:

rm -rf /tmp/c2h4n3-laptop-use-cases
mkdir -p /tmp/c2h4n3-laptop-use-cases
unzip -o project-c2h4n3-laptop-use-cases.zip -d /tmp/c2h4n3-laptop-use-cases

cp /tmp/c2h4n3-laptop-use-cases/components/LaptopUseCaseExplorer.tsx components/LaptopUseCaseExplorer.tsx
cp /tmp/c2h4n3-laptop-use-cases/app/laptops/page.tsx app/laptops/page.tsx

npm run check

Then test locally:
/laptops
