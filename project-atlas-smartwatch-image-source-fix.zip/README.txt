Project Atlas — Smartwatch Image Source Fix

Purpose:
Updates the 16 smartwatch product source URLs that failed during image sync.
The replacement URLs point to current official Garmin, OnePlus, Amazfit, and
Withings pages that expose usable product content more reliably.

Apply:

rm -rf /tmp/atlas-smartwatch-image-source-fix
mkdir -p /tmp/atlas-smartwatch-image-source-fix
unzip -o project-atlas-smartwatch-image-source-fix.zip -d /tmp/atlas-smartwatch-image-source-fix

cp /tmp/atlas-smartwatch-image-source-fix/data/products/smartwatches.ts data/products/smartwatches.ts

Then run:

npm run sync-product-images

After it completes, hard-refresh /smartwatches.

Then run:

npm run check

Important:
- Existing images are skipped, so Apple, Google, Fitbit, AI Glasses, and audio
  images are not overwritten.
- If any current official site still blocks automated downloading, send the
  sync summary and we can isolate only those remaining products.
