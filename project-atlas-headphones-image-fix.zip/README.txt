Project Atlas — Headphones & Earbuds Missing Image Fix

This package adds the 8 headphone/earbud images that were missing after the
existing image synchronizer ran.

Files added:
- sony-wf-1000xm6.webp
- bose-qc-ultra-earbuds-2.webp
- jabra-elite-10-gen-2.webp
- sony-wh-1000xm6.webp
- bose-qc-ultra-headphones-2.webp
- jbl-tour-one-m3.webp
- bowers-wilkins-px7-s3.webp
- soundcore-space-one-pro.webp

HOW TO APPLY

1. Drag this ZIP into the top-level Project-Atlas folder in Codespaces.

2. Run:

rm -rf /tmp/atlas-headphone-images
mkdir -p /tmp/atlas-headphone-images
unzip -o project-atlas-headphones-image-fix.zip -d /tmp/atlas-headphone-images
cp /tmp/atlas-headphone-images/public/products/*.webp public/products/

3. Restart the local development server.

4. Hard refresh the browser with Ctrl+Shift+R.

5. Check:
   /headphones-earbuds
   /best-headphones-earbuds
   /products/sony-wh-1000xm6
   /products/bose-qc-ultra-earbuds-2

6. Run:
   npm run check

Do not deploy until the local pages look correct.
