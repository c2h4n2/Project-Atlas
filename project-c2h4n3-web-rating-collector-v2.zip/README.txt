Project C2H4N3 — Public Web Rating Collector v2

This removes the Best Buy API key dependency from the normal rating workflow.

It searches public web results for exact product pages on known retailer and
manufacturer domains, opens those pages, reads Product.aggregateRating JSON-LD,
and accepts only strict exact brand/model matches.

Install:

rm -rf /tmp/c2h4n3-web-rating-v2
mkdir -p /tmp/c2h4n3-web-rating-v2

unzip -o project-c2h4n3-web-rating-collector-v2.zip \
  -d /tmp/c2h4n3-web-rating-v2

cp /tmp/c2h4n3-web-rating-v2/scripts/customer-ratings/web-search.ts scripts/customer-ratings/web-search.ts
cp /tmp/c2h4n3-web-rating-v2/scripts/customer-ratings/page-rating.ts scripts/customer-ratings/page-rating.ts
cp /tmp/c2h4n3-web-rating-v2/scripts/customer-ratings/web-collector.ts scripts/customer-ratings/web-collector.ts
cp /tmp/c2h4n3-web-rating-v2/scripts/collect-customer-ratings-web.ts scripts/collect-customer-ratings-web.ts
cp /tmp/c2h4n3-web-rating-v2/scripts/apply-web-rating-collector-v2.ts scripts/apply-web-rating-collector-v2.ts

npx tsx scripts/apply-web-rating-collector-v2.ts
npm run check

Test only 3 unrated products first:

npm run collect-ratings:web:test

If results look reasonable:

npm run collect-ratings:web:write
npx tsx scripts/import-customer-ratings.ts
npx tsx scripts/audit-customer-ratings.ts
npm run check

The existing Product Sync Engine is patched to use the public web collector.

Important:
- Some sites block automated requests.
- Some render ratings only after JavaScript.
- Some omit aggregateRating structured data.

Those cases are reported, not guessed.
