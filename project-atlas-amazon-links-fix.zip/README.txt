Project Atlas — Amazon Link Script Fix

This fixes the previous script error:
"affiliateLinks is not empty ... review manually."

The new script:
- Preserves any existing retailer placeholders/links.
- Adds Amazon first when Amazon is not already present.
- Uses tracking ID chhx2nun03-20.
- Works even when affiliateLinks contains placeholder retailer objects with blank URLs.

Apply:

rm -rf /tmp/atlas-amazon-links-fix
mkdir -p /tmp/atlas-amazon-links-fix
unzip -o project-atlas-amazon-links-fix.zip -d /tmp/atlas-amazon-links-fix

cp /tmp/atlas-amazon-links-fix/scripts/affiliate-links/add-amazon-links.ts scripts/affiliate-links/add-amazon-links.ts

Then run:

npx tsx scripts/affiliate-links/add-amazon-links.ts
npx tsx scripts/affiliate-links/audit-retailer-links.ts
npm run check

Expected audit after success:
Products: 75
With retailer links: 75
Without retailer links: 0
Amazon: 75
