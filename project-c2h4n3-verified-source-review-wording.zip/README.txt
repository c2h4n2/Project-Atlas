Project C2H4N3 — Verified Source Review Wording

Important wording choice:
"Verified source" means C2H4N3 has verified that the retailer/manufacturer
page is an exact product/model match.

It does NOT claim that every individual review is a retailer-verified purchase.

This avoids misleading users while still communicating that C2H4N3 validates
the source before including its rating.

Apply:

rm -rf /tmp/c2h4n3-verified-source-wording
mkdir -p /tmp/c2h4n3-verified-source-wording
unzip -o project-c2h4n3-verified-source-review-wording.zip -d /tmp/c2h4n3-verified-source-wording

cp /tmp/c2h4n3-verified-source-wording/components/CustomerRating.tsx components/CustomerRating.tsx
cp /tmp/c2h4n3-verified-source-wording/components/CustomerRatingBreakdown.tsx components/CustomerRatingBreakdown.tsx

npm run check

Then launch:
npm run dev -- --hostname 0.0.0.0
