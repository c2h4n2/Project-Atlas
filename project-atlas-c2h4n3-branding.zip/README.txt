C2H4N3 Branding Update

This package replaces the current text logo in the header with the new tech-style C2H4N3 logo.

Apply:

rm -rf /tmp/c2h4n3-branding
mkdir -p /tmp/c2h4n3-branding
unzip -o project-atlas-c2h4n3-branding.zip -d /tmp/c2h4n3-branding

mkdir -p public/brand
cp /tmp/c2h4n3-branding/public/brand/c2h4n3-header.webp public/brand/c2h4n3-header.webp
cp /tmp/c2h4n3-branding/components/Header.tsx components/Header.tsx

Then:

npm run check

Restart the local site if needed:

npm run dev -- --hostname 0.0.0.0

Hard-refresh the homepage and verify the header on desktop and mobile.

This update only changes the header branding. It does not rename metadata, page titles,
footer copy, Search Console property, or domain.
