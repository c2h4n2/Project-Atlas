Project C2H4N3 — Universal Customer Rating on Product Cards

This patch enforces the Customer Rating panel on every ProductCard.

Because AI Glasses, Headphones & Earbuds, Smartwatches, Laptops,
Monitors, All Products, Top Picks, and best-of pages use ProductCard,
the customer rating panel will appear consistently across all of them.

Apply:

rm -rf /tmp/c2h4n3-universal-rating
mkdir -p /tmp/c2h4n3-universal-rating
unzip -o project-c2h4n3-universal-customer-rating.zip -d /tmp/c2h4n3-universal-rating

cp /tmp/c2h4n3-universal-rating/scripts/apply-universal-customer-rating.ts scripts/apply-universal-customer-rating.ts
cp /tmp/c2h4n3-universal-rating/scripts/audit-universal-customer-rating.ts scripts/audit-universal-customer-rating.ts

npx tsx scripts/apply-universal-customer-rating.ts
npx tsx scripts/audit-universal-customer-rating.ts
npm run check

Then launch locally:

npm run dev -- --hostname 0.0.0.0

Check:
- /all-products
- /ai-glasses
- /headphones-earbuds
- /smartwatches
- /laptops
- /monitors
- /top-picks

Products with real customer data will show:
★★★★★ 4.7 / 5
1,383 online customer reviews

Products without customer data will show:
★ Not Rated
No exact-match online rating added yet.
