Project C2H4N3 — Customer Rating Sync

Purpose
-------
Maintain exact-match customer review ratings in one CSV instead of
editing 155+ product files manually.

CSV columns
-----------
slug,platform,rating,reviewCount,url,checkedAt

Example:
sony-wh-1000xm6,Best Buy,4.8,1383,https://exact-product-page,2026-08-09
sony-wh-1000xm6,Amazon,4.6,1021,https://exact-product-page,2026-08-09
sony-wh-1000xm6,Walmart,4.5,443,https://exact-product-page,2026-08-09

Rules
-----
- Exact product/model match only.
- Rating must be > 0 and <= 5.
- reviewCount must be a positive integer.
- checkedAt must be YYYY-MM-DD.
- URL must point to the exact product page.
- The importer rejects unknown slugs and duplicate sources.
- Existing manufacturer/editorial source entries are preserved.
- Customer rating is automatically weighted by review count.

Apply
-----
rm -rf /tmp/c2h4n3-rating-sync
mkdir -p /tmp/c2h4n3-rating-sync
unzip -o project-c2h4n3-customer-rating-sync.zip -d /tmp/c2h4n3-rating-sync

mkdir -p lib customer-ratings

cp /tmp/c2h4n3-rating-sync/data/customer-ratings.ts data/customer-ratings.ts
cp /tmp/c2h4n3-rating-sync/lib/apply-customer-ratings.ts lib/apply-customer-ratings.ts
cp /tmp/c2h4n3-rating-sync/scripts/import-customer-ratings.ts scripts/import-customer-ratings.ts
cp /tmp/c2h4n3-rating-sync/scripts/audit-customer-ratings.ts scripts/audit-customer-ratings.ts
cp /tmp/c2h4n3-rating-sync/scripts/apply-customer-rating-sync.ts scripts/apply-customer-rating-sync.ts
cp /tmp/c2h4n3-rating-sync/customer-ratings/customer-ratings.csv customer-ratings/customer-ratings.csv

npx tsx scripts/apply-customer-rating-sync.ts
npm run check

Workflow
--------
1. Edit customer-ratings/customer-ratings.csv
2. Add exact-match source rows.
3. Import:

npx tsx scripts/import-customer-ratings.ts

4. Audit:

npx tsx scripts/audit-customer-ratings.ts

5. Build:

npm run check

The live site will then automatically show the weighted customer score
and per-source breakdown using the rating UI already installed.

IMPORTANT
---------
The included CSV has a placeholder URL. Replace or remove that sample row
before importing. It is only there to demonstrate the expected format.
