export type CustomerRatingEntry = {
  platform: string;
  rating: number;
  reviewCount: number;
  url: string;
  checkedAt: string;
};

export const customerRatingsBySlug: Record<
  string,
  CustomerRatingEntry[]
> = {};
