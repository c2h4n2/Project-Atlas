Project C2H4N3 — Preserve Existing Customer Ratings

This fixes the Customer Rating Sync so it does NOT erase customer ratings
already present in the product catalog.

Priority:
1. Exact-match synced sources from data/customer-ratings.ts
2. Existing valid product.customerRating + totalReviewCount
3. Not Rated only when neither exists

Apply:

rm -rf /tmp/c2h4n3-rating-preserve
mkdir -p /tmp/c2h4n3-rating-preserve
unzip -o project-c2h4n3-customer-rating-preserve-fallback.zip -d /tmp/c2h4n3-rating-preserve

cp /tmp/c2h4n3-rating-preserve/lib/apply-customer-ratings.ts lib/apply-customer-ratings.ts

npm run check

Then launch:
npm run dev -- --hostname 0.0.0.0

This will make every card with existing customer rating data show its number
again, while products with no real rating data remain Not Rated.
