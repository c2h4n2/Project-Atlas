Project C2H4N3 — Multi-source Customer Ratings

Adds:
- review-count weighted combined ratings
- per-source rating table on product pages
- combined customer rating vs C2H4N3 score
- exact-match source requirement

Apply:

rm -rf /tmp/c2h4n3-customer-ratings
mkdir -p /tmp/c2h4n3-customer-ratings
unzip -o project-c2h4n3-customer-rating-breakdown.zip -d /tmp/c2h4n3-customer-ratings

mkdir -p lib
cp /tmp/c2h4n3-customer-ratings/lib/customer-ratings.ts lib/customer-ratings.ts
cp /tmp/c2h4n3-customer-ratings/components/CustomerRating.tsx components/CustomerRating.tsx
cp /tmp/c2h4n3-customer-ratings/components/CustomerRatingBreakdown.tsx components/CustomerRatingBreakdown.tsx
cp /tmp/c2h4n3-customer-ratings/scripts/apply-customer-rating-breakdown.ts scripts/apply-customer-rating-breakdown.ts

npx tsx scripts/apply-customer-rating-breakdown.ts
npm run check

Important:
This builds the system only. It does not invent ratings.
Products remain Not Rated until exact-match source data is added to sources[].
