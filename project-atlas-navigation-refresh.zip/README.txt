Project Atlas — Navigation Refresh

Changes:
- Header is now: Home | All Products | About | Contact
- Removed Categories, Best Products, and Compare from the header
- Homepage hero now has:
  Categories | All Products | Top Picks | Compare Products
- Categories is a dropdown with:
  AI Glasses
  Headphones & Earbuds
- Added /all-products
- Added /top-picks
- Homepage featured grid is limited to the top 12 products to keep the page manageable
- Existing product/category/compare pages are not replaced

HOW TO APPLY

1. Drag project-atlas-navigation-refresh.zip into the top-level Project-Atlas folder in Codespaces.

2. Run:

rm -rf /tmp/atlas-navigation-refresh
mkdir -p /tmp/atlas-navigation-refresh
unzip -o project-atlas-navigation-refresh.zip -d /tmp/atlas-navigation-refresh

cp /tmp/atlas-navigation-refresh/components/Header.tsx components/Header.tsx
cp /tmp/atlas-navigation-refresh/components/HeroActions.tsx components/HeroActions.tsx
cp /tmp/atlas-navigation-refresh/app/page.tsx app/page.tsx

mkdir -p app/all-products
mkdir -p app/top-picks

cp /tmp/atlas-navigation-refresh/app/all-products/page.tsx app/all-products/page.tsx
cp /tmp/atlas-navigation-refresh/app/top-picks/page.tsx app/top-picks/page.tsx

3. Run:

npm run check

4. Start or restart local dev server:

npm run dev -- --hostname 0.0.0.0

5. Test locally:
/
 /all-products
 /top-picks
 /compare
 /ai-glasses
 /headphones-earbuds

6. Do not deploy until the local layout looks correct.
