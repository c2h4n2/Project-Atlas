import type { Metadata } from "next";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";

export const metadata: Metadata = {
  title: "All Products",
  description:
    "Browse every product reviewed by Project Atlas across all available categories.",
};

export default function AllProductsPage() {
  const sortedProducts = [...products].sort((a, b) => {
    if (a.category !== b.category) {
      return a.category.localeCompare(b.category);
    }

    return b.editorialScore - a.editorialScore;
  });

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <section className="border-b border-white/10">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
            Complete catalog
          </p>

          <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-6xl">
            All Products
          </h1>

          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
            Browse every product currently reviewed by Project Atlas across AI
            glasses, headphones, and earbuds.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/ai-glasses"
              className="rounded-full border border-white/20 bg-white/5 px-5 py-3 text-sm font-semibold transition hover:border-cyan-400/50 hover:bg-white/10"
            >
              AI Glasses
            </Link>

            <Link
              href="/headphones-earbuds"
              className="rounded-full border border-white/20 bg-white/5 px-5 py-3 text-sm font-semibold transition hover:border-cyan-400/50 hover:bg-white/10"
            >
              Headphones & Earbuds
            </Link>

            <Link
              href="/top-picks"
              className="rounded-full border border-cyan-400/30 bg-cyan-400/5 px-5 py-3 text-sm font-semibold text-cyan-300 transition hover:bg-cyan-400/10"
            >
              View Top Picks
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-14 sm:py-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-cyan-400">
              {sortedProducts.length} products
            </p>

            <h2 className="mt-2 text-3xl font-bold">
              Every current Atlas review
            </h2>
          </div>
        </div>

        <div className="grid gap-7 md:grid-cols-2 xl:grid-cols-3">
          {sortedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </main>
  );
}
