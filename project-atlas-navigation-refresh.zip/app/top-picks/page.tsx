import type { Metadata } from "next";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";

export const metadata: Metadata = {
  title: "Top Picks",
  description:
    "See Project Atlas top-rated products across every active product category.",
};

export default function TopPicksPage() {
  const aiGlasses = products
    .filter((product) => (product.categoryId ?? "ai-glasses") === "ai-glasses")
    .sort((a, b) => b.editorialScore - a.editorialScore)
    .slice(0, 3);

  const audioProducts = products
    .filter((product) => product.categoryId === "headphones-earbuds")
    .sort((a, b) => b.editorialScore - a.editorialScore)
    .slice(0, 3);

  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <section className="border-b border-white/10">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">
            Atlas rankings
          </p>

          <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-6xl">
            Top Picks
          </h1>

          <p className="mt-6 max-w-3xl text-lg leading-8 text-slate-300">
            Start with our highest-rated products in each active category.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-14 sm:py-16">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-cyan-400">
              AI Glasses
            </p>
            <h2 className="mt-2 text-3xl font-bold">Top AI Glasses</h2>
          </div>

          <Link
            href="/best-ai-glasses"
            className="text-sm font-semibold text-cyan-400 transition hover:text-cyan-300"
          >
            View full AI Glasses rankings →
          </Link>
        </div>

        <div className="mt-8 grid gap-7 md:grid-cols-2 xl:grid-cols-3">
          {aiGlasses.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              rank={index + 1}
            />
          ))}
        </div>

        <div className="mt-16 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-cyan-400">
              Headphones & Earbuds
            </p>
            <h2 className="mt-2 text-3xl font-bold">
              Top Headphones & Earbuds
            </h2>
          </div>

          <Link
            href="/best-headphones-earbuds"
            className="text-sm font-semibold text-cyan-400 transition hover:text-cyan-300"
          >
            View full audio rankings →
          </Link>
        </div>

        <div className="mt-8 grid gap-7 md:grid-cols-2 xl:grid-cols-3">
          {audioProducts.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              rank={index + 1}
            />
          ))}
        </div>
      </section>
    </main>
  );
}
