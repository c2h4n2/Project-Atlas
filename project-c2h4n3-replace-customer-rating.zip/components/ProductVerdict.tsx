import type { Product } from "@/data/products";

function getVerdict(product: Product) {
  if (product.qualification === "top-pick" || product.editorialScore >= 9.2) {
    return {
      label: "Highly Recommended",
      detail: "One of our strongest choices in its category.",
    };
  }

  if (product.qualification === "strong-pick" || product.editorialScore >= 8.7) {
    return {
      label: "Strong Buy",
      detail: "A compelling choice for the right buyer.",
    };
  }

  if (product.editorialScore >= 8.2) {
    return {
      label: "Good Choice",
      detail: "Well worth considering against similar products.",
    };
  }

  return {
    label: "Consider Alternatives",
    detail: "Compare closely with stronger options before buying.",
  };
}

export default function ProductVerdict({ product }: { product: Product }) {
  const verdict = getVerdict(product);

  return (
    <div>
      <p className="text-lg font-black text-white">{verdict.label}</p>
      <p className="mt-1 text-[11px] leading-4 text-slate-400">
        {verdict.detail}
      </p>
    </div>
  );
}
