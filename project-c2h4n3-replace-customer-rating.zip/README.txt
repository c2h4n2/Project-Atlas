Project C2H4N3 — Replace Customer Rating

Removes:
- Customer Rating card
- Trust Meter
- Customer rating breakdown on product detail pages

Adds:
- C2H4N3 Verdict based on editorial score and qualification

Apply:

rm -rf /tmp/c2h4n3-replace-customer-rating
mkdir -p /tmp/c2h4n3-replace-customer-rating

unzip -o project-c2h4n3-replace-customer-rating.zip -d /tmp/c2h4n3-replace-customer-rating

cp /tmp/c2h4n3-replace-customer-rating/components/ProductVerdict.tsx components/ProductVerdict.tsx
cp /tmp/c2h4n3-replace-customer-rating/scripts/apply-replace-customer-rating.ts scripts/apply-replace-customer-rating.ts

npx tsx scripts/apply-replace-customer-rating.ts
npm run check

Then launch:
npm run dev -- --hostname 0.0.0.0
