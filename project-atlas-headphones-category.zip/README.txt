Project Atlas — Headphones & Earbuds category

Copy the files from this package into your Project Atlas repository using the same paths.

Important:
- Keep your current data/products/ai-glasses.ts if it contains newer corrections.
- The included copy is only a fallback.
- The 25 new audio products use official manufacturer sources.
- Customer ratings are intentionally left blank in the data rather than invented.

After copying the files, run:

npm run check

Then start the site:

npm run dev -- --hostname 0.0.0.0

Check these pages:

/headphones-earbuds
/best-headphones-earbuds
/compare?category=headphones-earbuds
/products/sony-wh-1000xm6
