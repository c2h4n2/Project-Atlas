Project Atlas — Compare Suspense fix

This fixes:
useSearchParams() should be wrapped in a suspense boundary at page "/compare".

Replace/create:
app/compare/page.tsx
app/compare/CompareClient.tsx

Then run:
npm run check
