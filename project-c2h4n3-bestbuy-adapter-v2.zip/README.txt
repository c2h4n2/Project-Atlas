Project C2H4N3 — Best Buy Adapter v2

Why this patch exists
=====================
The previous Best Buy adapter generated the Products API URL with TWO nested
sets of parentheses:

/v1/products((search=foo&search=bar))

Best Buy's official Products API syntax uses ONE set:

/v1/products(search=foo&search=bar)

That malformed request is a likely reason every Best Buy lookup failed.

This patch also improves diagnostics so future API failures show:
- HTTP status
- redacted request URL
- first part of the API response body

Install
=======
rm -rf /tmp/c2h4n3-bestbuy-v2
mkdir -p /tmp/c2h4n3-bestbuy-v2

unzip -o project-c2h4n3-bestbuy-adapter-v2.zip \
  -d /tmp/c2h4n3-bestbuy-v2

cp /tmp/c2h4n3-bestbuy-v2/scripts/customer-ratings/bestbuy.ts \
  scripts/customer-ratings/bestbuy.ts

cp /tmp/c2h4n3-bestbuy-v2/scripts/test-bestbuy-rating.ts \
  scripts/test-bestbuy-rating.ts

Test ONE known product first
============================
Make sure the key is set:

export BEST_BUY_API_KEY="YOUR_KEY"

Then:

npx tsx scripts/test-bestbuy-rating.ts samsung-galaxy-watch8-classic

You may also test:

npx tsx scripts/test-bestbuy-rating.ts dell-ultrasharp-u3226q

If the diagnostic returns candidates successfully, then run:

npm run sync-products:ratings-only

Do NOT run all 129 again until the one-product diagnostic works.
