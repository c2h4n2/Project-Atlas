Project Atlas — Search Filter Fix

Fix:
- Typing an exact brand name such as Sony now shows only that brand.
- General search now searches product names and brands only.
- It no longer matches hidden words inside descriptions or "Best for" text.
- Search placeholder changed to "Search by product or brand..."

Apply:

rm -rf /tmp/atlas-search-fix
mkdir -p /tmp/atlas-search-fix
unzip -o project-atlas-search-filter-fix.zip -d /tmp/atlas-search-fix
cp /tmp/atlas-search-fix/components/ProductExplorer.tsx components/ProductExplorer.tsx

Then:
npm run check

Test locally:
- Sony -> only Sony
- Samsung -> only Samsung
- Apple -> only Apple
- AirPods -> AirPods products
- XREAL -> XREAL products
