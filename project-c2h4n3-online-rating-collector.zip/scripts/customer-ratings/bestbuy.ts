import { scoreExactProductMatch } from "./matching";
import type { CatalogProduct, RatingCandidate } from "./types";

type BestBuyProduct = {
  name?: string;
  sku?: number;
  url?: string;
  customerReviewAverage?: number;
  customerReviewCount?: number;
  manufacturer?: string;
  modelNumber?: string;
};

type BestBuyResponse = {
  products?: BestBuyProduct[];
};

function escapeSearchTerm(value: string) {
  return value
    .replace(/[()]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export async function collectFromBestBuy(
  product: CatalogProduct,
  apiKey: string,
): Promise<RatingCandidate[]> {
  const terms = escapeSearchTerm(`${product.brand} ${product.name}`)
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 10);

  if (terms.length === 0) return [];

  const filter = terms
    .map((term) => `search=${encodeURIComponent(term)}`)
    .join("&");

  const show = [
    "name",
    "sku",
    "url",
    "customerReviewAverage",
    "customerReviewCount",
    "manufacturer",
    "modelNumber",
  ].join(",");

  const url =
    `https://api.bestbuy.com/v1/products((${filter}))` +
    `?apiKey=${encodeURIComponent(apiKey)}` +
    `&format=json&pageSize=20&show=${encodeURIComponent(show)}`;

  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(
      `Best Buy API ${response.status} ${response.statusText}`,
    );
  }

  const data = (await response.json()) as BestBuyResponse;
  const candidates: RatingCandidate[] = [];

  for (const item of data.products ?? []) {
    const rating = Number(item.customerReviewAverage ?? 0);
    const reviewCount = Number(item.customerReviewCount ?? 0);
    const itemName = item.name?.trim() ?? "";

    if (
      !itemName ||
      !Number.isFinite(rating) ||
      rating <= 0 ||
      rating > 5 ||
      !Number.isFinite(reviewCount) ||
      reviewCount <= 0
    ) {
      continue;
    }

    const match = scoreExactProductMatch(
      product.name,
      product.brand,
      `${item.manufacturer ?? ""} ${itemName} ${item.modelNumber ?? ""}`,
    );

    candidates.push({
      slug: product.slug,
      platform: "Best Buy",
      productName: itemName,
      rating,
      reviewCount: Math.round(reviewCount),
      url: item.url ?? `https://www.bestbuy.com/site/searchpage.jsp?st=${encodeURIComponent(product.name)}`,
      checkedAt: new Date().toISOString().slice(0, 10),
      matchScore: match.score,
      exactMatch: match.exact,
      evidence: [
        ...match.evidence,
        item.modelNumber
          ? `Best Buy model: ${item.modelNumber}`
          : "Best Buy model number unavailable",
        item.sku ? `Best Buy SKU: ${item.sku}` : "Best Buy SKU unavailable",
      ],
    });
  }

  return candidates.sort((a, b) => b.matchScore - a.matchScore);
}
