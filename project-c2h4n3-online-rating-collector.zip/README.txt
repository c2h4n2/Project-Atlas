Project C2H4N3 — Online Customer Rating Collector

WHAT IT DOES
============
This adds the missing online collection layer in front of the Customer Rating
Sync that is already installed.

Pipeline:

C2H4N3 catalog
  -> Online Rating Collector
  -> exact-model validation
  -> customer-ratings/customer-ratings.csv
  -> existing importer
  -> data/customer-ratings.ts
  -> cards + Trust Meter

COLLECTORS
==========
1. Best Buy API
   - Automatically searches the Best Buy product catalog.
   - Reads customerReviewAverage and customerReviewCount.
   - Rejects candidates that fail strict model/configuration matching.
   - Requires BEST_BUY_API_KEY.

2. Direct Product Page / JSON-LD
   - Works with exact retailer/manufacturer URLs placed in:
     customer-ratings/source-seeds.csv
   - Reads Schema.org Product.aggregateRating JSON-LD.
   - Validates product/model name before accepting.
   - Useful for Walmart, manufacturer stores, and other pages that expose
     aggregateRating structured data.
   - Some sites block automated requests or render ratings only in JavaScript;
     those are reported for manual review instead of fabricated.

SAFETY
======
- Dry run by default.
- Only strict exact matches are written automatically.
- Ambiguous model/configuration matches go to collector-report.json.
- Existing customer-ratings.csv rows are preserved.
- Ratings are never invented.
- Source URL and checked date are retained.

INSTALL
=======
rm -rf /tmp/c2h4n3-online-rating-collector
mkdir -p /tmp/c2h4n3-online-rating-collector

unzip -o project-c2h4n3-online-rating-collector.zip \
  -d /tmp/c2h4n3-online-rating-collector

mkdir -p scripts/customer-ratings customer-ratings

cp /tmp/c2h4n3-online-rating-collector/scripts/collect-customer-ratings.ts \
  scripts/collect-customer-ratings.ts

cp /tmp/c2h4n3-online-rating-collector/scripts/customer-ratings/*.ts \
  scripts/customer-ratings/

cp /tmp/c2h4n3-online-rating-collector/customer-ratings/source-seeds.csv \
  customer-ratings/source-seeds.csv

npm run check

BEST BUY SETUP
==============
Create a Best Buy Developer API key and then in Codespaces:

export BEST_BUY_API_KEY="YOUR_KEY_HERE"

Do not commit the key.

RUN
===
First test without writing:

npx tsx scripts/collect-customer-ratings.ts --only-unrated

Review:
customer-ratings/collector-report.json

Then write accepted exact matches:

npx tsx scripts/collect-customer-ratings.ts --only-unrated --write

Import and audit:

npx tsx scripts/import-customer-ratings.ts
npx tsx scripts/audit-customer-ratings.ts
npm run check

DIRECT SOURCES
==============
For products not found through an API, add exact product URLs to:

customer-ratings/source-seeds.csv

Format:

slug,platform,url
samsung-galaxy-watch8-classic,Walmart,https://www.walmart.com/ip/EXACT-ITEM
dell-ultrasharp-u3226q,Dell,https://www.dell.com/en-us/shop/EXACT-PAGE

Then rerun the collector.

IMPORTANT
=========
Automatic collection is only as reliable as the retailer's public API or
structured product data. Sites that block bots, require login, or hide ratings
behind client-side requests will be reported rather than guessed.
