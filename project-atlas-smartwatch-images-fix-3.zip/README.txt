Project Atlas Smartwatch Images Fix #3

rm -rf /tmp/atlas-smartwatch-images-fix-3
mkdir -p /tmp/atlas-smartwatch-images-fix-3
unzip -o project-atlas-smartwatch-images-fix-3.zip -d /tmp/atlas-smartwatch-images-fix-3

cp /tmp/atlas-smartwatch-images-fix-3/public/products/*.webp public/products/

npm run check
