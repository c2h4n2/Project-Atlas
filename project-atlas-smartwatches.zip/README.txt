Project Atlas — Smartwatches Category Release

Adds:
- 25 smartwatch products
- /smartwatches
- /best-smartwatches
- Smartwatches in the homepage Categories dropdown
- Smartwatches in Top Picks
- Smartwatch-specific comparison labels/specifications
- All Products automatically grows from 50 to 75 products
- Existing search/filter/sort component works automatically with the new category

IMPORTANT:
- This release does NOT overwrite your working AI Glasses or Headphones & Earbuds product files.
- Smartwatch customer ratings are intentionally left as "New" instead of inventing review numbers.
- Affiliate links are intentionally empty so Amazon Associates links can be added later with your real tracking ID.
- Smartwatch image paths are prepared, but images still need to be synchronized/downloaded after install.

HOW TO APPLY

1. Drag project-atlas-smartwatches.zip into the top-level Project-Atlas folder.

2. Run:

rm -rf /tmp/atlas-smartwatches
mkdir -p /tmp/atlas-smartwatches
unzip -o project-atlas-smartwatches.zip -d /tmp/atlas-smartwatches

cp /tmp/atlas-smartwatches/data/categories.ts data/categories.ts
cp /tmp/atlas-smartwatches/data/products.ts data/products.ts
cp /tmp/atlas-smartwatches/data/products/smartwatches.ts data/products/smartwatches.ts

cp /tmp/atlas-smartwatches/components/HeroActions.tsx components/HeroActions.tsx
cp /tmp/atlas-smartwatches/app/top-picks/page.tsx app/top-picks/page.tsx

mkdir -p app/smartwatches
mkdir -p app/best-smartwatches

cp /tmp/atlas-smartwatches/app/smartwatches/page.tsx app/smartwatches/page.tsx
cp /tmp/atlas-smartwatches/app/best-smartwatches/page.tsx app/best-smartwatches/page.tsx

3. Run:

npm run check

4. If the build passes, synchronize images:

npm run sync-product-images

5. Restart local site:

npm run dev -- --hostname 0.0.0.0

6. Test locally:
/
 /all-products
 /top-picks
 /smartwatches
 /best-smartwatches
 /compare?category=smartwatches
 /products/apple-watch-series-11
 /products/samsung-galaxy-watch9
 /products/google-pixel-watch-4-45mm
 /products/garmin-forerunner-970

7. Do not deploy until local pages and images look correct.
