C2H4N3 Rating Collector CJS Fix

Replaces scripts/collect-customer-ratings.ts with a version that wraps all
async work inside async function main(), so tsx/CommonJS can run it.

Apply:

rm -rf /tmp/c2h4n3-rating-cjs-fix
mkdir -p /tmp/c2h4n3-rating-cjs-fix
unzip -o project-c2h4n3-rating-collector-cjs-fix.zip -d /tmp/c2h4n3-rating-cjs-fix

cp /tmp/c2h4n3-rating-cjs-fix/scripts/collect-customer-ratings.ts scripts/collect-customer-ratings.ts

npm run sync-products:dry
