Project Atlas - Smartwatch Images Fix #2

Apply:

rm -rf /tmp/atlas-smartwatch-images-fix-2
mkdir -p /tmp/atlas-smartwatch-images-fix-2
unzip -o project-atlas-smartwatch-images-fix-2.zip -d /tmp/atlas-smartwatch-images-fix-2

cp /tmp/atlas-smartwatch-images-fix-2/public/products/*.webp public/products/

npm run check
