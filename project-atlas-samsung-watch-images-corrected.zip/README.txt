Project Atlas — Corrected Samsung Watch Images

This package replaces the three incorrect Samsung-logo files with actual watch images.

Apply:

rm -rf /tmp/atlas-samsung-watch-corrected
mkdir -p /tmp/atlas-samsung-watch-corrected
unzip -o project-atlas-samsung-watch-images-corrected.zip -d /tmp/atlas-samsung-watch-corrected

cp -f /tmp/atlas-samsung-watch-corrected/public/products/*.webp public/products/

Verify file sizes:

ls -lh public/products/samsung-galaxy-watch*.webp

Then clear Next.js cache and restart:

rm -rf .next
npm run dev -- --hostname 0.0.0.0

Hard refresh /smartwatches.

Finally:
npm run check
