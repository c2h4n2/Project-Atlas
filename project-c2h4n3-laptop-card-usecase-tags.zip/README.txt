Project C2H4N3 — Laptop Card Use-Case Tags

For laptop cards only, replaces generic Best for lines with:
- Study
- Business
- Engineering
- Gaming
- Coding

Example:
ROG Zephyrus G14 (2026)
Best for
✓ Gaming
✓ Engineering
✓ Coding

Non-laptop categories are unchanged.

Apply:

rm -rf /tmp/c2h4n3-laptop-card-tags
mkdir -p /tmp/c2h4n3-laptop-card-tags
unzip -o project-c2h4n3-laptop-card-usecase-tags.zip -d /tmp/c2h4n3-laptop-card-tags

cp /tmp/c2h4n3-laptop-card-tags/data/laptop-use-cases.ts data/laptop-use-cases.ts
cp /tmp/c2h4n3-laptop-card-tags/scripts/apply-laptop-card-usecases.ts scripts/apply-laptop-card-usecases.ts

npx tsx scripts/apply-laptop-card-usecases.ts
npm run check

Then test locally:
/laptops
/best-laptops
/all-products
